<?php
/**
 * Product Loop End
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package woocommerce
 * @version 2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
</ul>
